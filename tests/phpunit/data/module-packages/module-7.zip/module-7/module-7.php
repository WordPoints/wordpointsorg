<?php

/**
 * Module Name: Module 7
 * Author:      J.D. Grimes
 * Author URI:  http://codesymphony.co/
 * Module URI:  http://codesymphony.co/
 * Version:     1.0.0
 * License:     GPLv2+
 * Description: Description.
 * Update API:  wordpoints.org
 * ID:          7
 */

// Code here.

// EOF
